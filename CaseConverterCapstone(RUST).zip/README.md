# Rust Case Converter – Beginner Project

This is a small Rust CLI program that converts the case of text you enter.

## How to run
1. Install Rust: https://rustup.rs
2. Run:
```
cargo run
```

## Author
Nyawira Ndirangu

## Repository
https://github.com/NyawiraNdirangu/rust-case-converter-capstone
