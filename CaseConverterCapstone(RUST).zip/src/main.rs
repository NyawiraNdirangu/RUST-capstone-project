use std::io::{self, Write};

fn main() {
    println!("Rust Text Case Converter");
    println!("-------------------------");

    print!("Enter text: ");
    io::stdout().flush().unwrap();
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read input");
    let input = input.trim_end().to_string();

    println!("
Choose conversion:");
    println!("  1) UPPERCASE");
    println!("  2) lowercase");
    println!("  3) Toggle case (upper <-> lower per character)");
    print!("Enter 1, 2, or 3: ");
    io::stdout().flush().unwrap();

    let mut choice = String::new();
    io::stdin().read_line(&mut choice).expect("Failed to read choice");
    let choice = choice.trim();

    match choice {
        "1" => println!("
Result:
{}", input.to_uppercase()),
        "2" => println!("
Result:
{}", input.to_lowercase()),
        "3" => {
            let toggled: String = input.chars().map(|c| {
                if c.is_lowercase() {
                    c.to_uppercase().next().unwrap_or(c)
                } else {
                    c.to_lowercase().next().unwrap_or(c)
                }
            }).collect();
            println!("
Result:
{}", toggled);
        }
        _ => println!("
Invalid choice."),
    }
}
