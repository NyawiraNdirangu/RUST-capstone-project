# Rust Case Converter — Toolkit Document

Created by **Nyawira Ndirangu**  
GitHub username: **NyawiraNdirangu**

Full toolkit documentation describing setup, code, prompts, issues and references.
